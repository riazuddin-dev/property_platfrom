const API = process.env.NEXT_PUBLIC_API_URL;

export const getDashboardStats = async () => {
  try {
    const res = await fetch(`${API}/dashboard-stats`, {
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
    });

    console.log("Dashboard Status:", res.status);

   if (!res.ok) {
  const error = await res.text();

  console.log("Status:", res.status);
  console.log("Response:", error);

  return null;
}

    const data = await res.json();
    console.log("✅ Dashboard Data:", data);
    return data;
  } catch (err) {
    console.error("Fetch Error:", err);
    return null;
  }
};